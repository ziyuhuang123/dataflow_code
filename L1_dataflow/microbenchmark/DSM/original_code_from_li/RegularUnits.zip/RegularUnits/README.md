## Reference

https://github.com/shen203/GPU_Microbenchmark