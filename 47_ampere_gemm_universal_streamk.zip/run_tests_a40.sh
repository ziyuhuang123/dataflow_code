#!/bin/bash

# 输出 CSV 文件
output_file="/home/zyhuang/cutlass/examples/47_ampere_gemm_universal_streamk/results_a40_FFN1_70B.csv"

# 初始化 CSV 文件，写入表头
echo "M,N,K,Swizzle,BaselineRatio,L2_Hit_Rate (%),Arithmetic Intensity,Performance Bound,sm__cycles_elapsed.avg,sm__cycles_elapsed.avg.per.second,sm__inst_executed_pipe_tensor.sum,dram__bytes.sum,Highlight,Total Time (seconds), base_ratio" > $output_file


# 定义参数范围
# ms=(1024 2048 16384 32768 65536)
# ns=(4096)
# ks=(14336)
# swizzles=(1 16 128)


ms=(1024 2048 16384 32768 65536)
ns=(8192)
ks=(28762)
swizzles=(1 16 128)


# 定义重复次数
REPEATS=1

# 遍历所有参数组合
for m in "${ms[@]}"; do
  for n in "${ns[@]}"; do
    for k in "${ks[@]}"; do
      baseline_time=0
      highlight=""

      for swizzle in "${swizzles[@]}"; do

        # 修改代码中的参数
        sed -i "s/problem_size({[0-9]\+,[0-9]\+,[0-9]\+})/problem_size({$m,$n,$k})/g" /home/zyhuang/cutlass/examples/47_ampere_gemm_universal_streamk/ampere_gemm_universal_streamk_a40.cu
        sed -i "s/GemmIdentityThreadblockSwizzle<[0-9]\+>/GemmIdentityThreadblockSwizzle<$swizzle>/g" /home/zyhuang/cutlass/examples/47_ampere_gemm_universal_streamk/ampere_gemm_universal_streamk_a40.cu

        # 编译
        (nvcc ampere_gemm_universal_streamk_a40.cu -o ampere_gemm_universal_streamk_a40 -arch=sm_86 -std=c++17 -I ../../include -I ../../tools/util/include)

        # 设置基线时间
        if [ "$swizzle" -eq 1 ]; then
          baseline_time=$(ncu --metrics sm__cycles_elapsed.avg,sm__cycles_elapsed.avg.per_second --target-processes all --clock-control=base --cache-control=all /home/zyhuang/cutlass/examples/47_ampere_gemm_universal_streamk/ampere_gemm_universal_streamk_a40 | grep -E "sm__cycles_elapsed.avg |sm__cycles_elapsed.avg.per.second" | awk '{print $3}' | tr '\n' ' ' | awk '{print $1 / $2}')
          baseline_time_seconds=$(echo "scale=6; $baseline_time / 10^6" | bc)
        fi

        # 初始化总计数器
        total_l2_hit_rate=0
        total_dram_bytes=0
        total_sm_cycles=0
        total_sm_cycles_per_second=0
        total_tensor_ops=0

        # 进行ncu分析，收集L2命中率和其他指标
        for i in $(seq 1 $REPEATS); do
          echo "Running ncu iteration $i for M=$m, N=$n, K=$k, Swizzle=$swizzle..."
          ncu_result=$(ncu --metrics sm__cycles_elapsed.avg,sm__cycles_elapsed.avg.per_second,sm__inst_executed_pipe_tensor.sum,dram__bytes.sum --target-processes all --section MemoryWorkloadAnalysis --clock-control=base --cache-control=all /home/zyhuang/cutlass/examples/47_ampere_gemm_universal_streamk/ampere_gemm_universal_streamk_a40)

          # 提取指标值并删除逗号
          dram_bytes_line=$(echo "$ncu_result" | grep "dram__bytes.sum")
          dram_bytes_value=$(echo "$dram_bytes_line" | awk '{print $3}' | tr -d ',')
          dram_bytes_unit=$(echo "$dram_bytes_line" | awk '{for(i=1;i<=NF;i++) if ($i == "Gbyte" || $i == "Mbyte") print $i}')
          sm_cycles=$(echo "$ncu_result" | grep "sm__cycles_elapsed.avg " | awk '{print $3}' | tr -d ',')
          sm_cycles_per_second=$(echo "$ncu_result" | grep "sm__cycles_elapsed.avg.per.second" | awk '{print $3}' | tr -d ',')
          tensor_ops=$(echo "$ncu_result" | grep "sm__inst_executed_pipe_tensor.sum" | awk '{print $3}' | tr -d ',')
          l2_hit_rate=$(echo "$ncu_result" | grep "L2 Hit Rate" | awk '{print $NF}' | tr -d '%')


          echo "dram_bytes_line: $dram_bytes_line"
          echo "dram_bytes_value: $dram_bytes_value"
          echo "dram_bytes_unit: $dram_bytes_unit"


          # 根据单位调整总字节数
          if [ "$dram_bytes_unit" == "Gbyte" ]; then
            dram_bytes=$(echo "scale=6; $dram_bytes_value * 10^9" | bc)
          elif [ "$dram_bytes_unit" == "Mbyte" ]; then
            dram_bytes=$(echo "scale=6; $dram_bytes_value * 10^6" | bc)
          else
            dram_bytes=$dram_bytes_value
          fi

          # 累加总值
          total_dram_bytes=$(echo "$total_dram_bytes + $dram_bytes" | bc)
          total_sm_cycles=$(echo "$total_sm_cycles + $sm_cycles" | bc)
          total_sm_cycles_per_second=$(echo "$total_sm_cycles_per_second + $sm_cycles_per_second" | bc)
          total_tensor_ops=$(echo "$total_tensor_ops + $tensor_ops" | bc)
          if [ -n "$l2_hit_rate" ]; then
            total_l2_hit_rate=$(echo "$total_l2_hit_rate + $l2_hit_rate" | bc)
          else
            echo "Failed to retrieve L2 Hit Rate for iteration $i"
          fi
        done

        # 计算平均值
        average_dram_bytes=$(echo "scale=6; $total_dram_bytes / $REPEATS" | bc)
        average_sm_cycles=$(echo "scale=6; $total_sm_cycles / $REPEATS" | bc)
        average_sm_cycles_per_second=$(echo "scale=6; $total_sm_cycles_per_second / $REPEATS" | bc)
        average_tensor_ops=$(echo "scale=6; $total_tensor_ops / $REPEATS" | bc)
        average_l2_hit_rate=$(echo "scale=2; $total_l2_hit_rate / $REPEATS" | bc)

        # 计算总时间 (秒)
        total_time_seconds=$(echo "scale=6; $average_sm_cycles / ($average_sm_cycles_per_second * 10^6)" | bc)

        # 计算基线比率
        baseline_ratio=$(echo "scale=4; $baseline_time_seconds / $total_time_seconds" | bc -l)

        # 计算总的FLOP数
        total_flops=$(echo "scale=6; $average_tensor_ops" | bc)

        # 计算算术强度
        arithmetic_intensity=$(echo "scale=6; $total_flops / $average_dram_bytes" | bc)

        # 计算结果乘以512
        arithmetic_intensity=$(echo "scale=6; $arithmetic_intensity * 512" | bc)



        echo "Total Time (seconds): $total_time_seconds"
        echo "baseline_time_seconds (seconds): $totbaseline_time_secondsal_time_seconds"
        echo "Baseline Ratio: $baseline_ratio"
        echo "Total FLOPs: $total_flops"
        echo "Total Bytes: $average_dram_bytes"
        echo "Arithmetic Intensity: $arithmetic_intensity"


        # 判断性能边界
        if (( $(echo "$arithmetic_intensity > 77" | bc -l) )); then
            performance_bound="compute bound"
        elif (( $(echo "$arithmetic_intensity < 77" | bc -l) )); then
            performance_bound="memory bound"
        else
            performance_bound="balanced"
        fi

        # 判断是否高亮
        if (( $(echo "$baseline_ratio > 1.2" | bc -l) )); then
            highlight="YES"
        fi

        # 写入 CSV 文件
        echo "$m,$n,$k,$swizzle,$baseline_ratio,$average_l2_hit_rate,$arithmetic_intensity,$performance_bound,$average_sm_cycles,$average_sm_cycles_per_second,$average_tensor_ops,$average_dram_bytes,$highlight,$total_time_seconds, $baseline_ratio" >> $output_file

      done
    done
  done
done
