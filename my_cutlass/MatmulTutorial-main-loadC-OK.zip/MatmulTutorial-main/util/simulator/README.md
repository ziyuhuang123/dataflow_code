## Utils for CUDA debugging and exercise
A python util for index debugging and displaying in CUDA programming via simulation

To run the scripts in this dir, remember to use
`PYTHONPATH=$PYTHONPATH:. python xxx.py`
in this dir.