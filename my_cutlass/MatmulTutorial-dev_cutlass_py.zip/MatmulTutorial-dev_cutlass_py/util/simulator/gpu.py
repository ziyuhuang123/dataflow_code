class GPU:
    def __init__(self, num_sm) -> None:
        self.num_sm = num_sm
