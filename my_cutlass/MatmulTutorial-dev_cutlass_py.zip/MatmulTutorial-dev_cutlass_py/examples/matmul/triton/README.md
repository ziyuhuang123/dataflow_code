```sh
cd 3rdparty/triton/python
pip install -e .
```