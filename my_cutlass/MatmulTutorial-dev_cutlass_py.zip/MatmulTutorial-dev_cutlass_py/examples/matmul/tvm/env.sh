export TVM_HOME=$(pwd)/../../../3rdparty/tvm
export PYTHONPATH=$TVM_HOME/python:${PYTHONPATH}