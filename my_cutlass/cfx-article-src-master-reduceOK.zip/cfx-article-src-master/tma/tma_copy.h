#pragma once

#include <cassert>
#include <cstdio>
#include <cstdlib>

#include <chrono>

#include <thrust/device_vector.h>
#include <thrust/host_vector.h>

#include "cutlass/numeric_types.h"
#include <cute/arch/cluster_sm90.hpp>
#include <cute/tensor.hpp>
#include <cutlass/arch/barrier.h>
#include <cutlass/cluster_launch.hpp>
#include <cutlass/cutlass.h>
#include <cute/util/print.hpp>

#include "cutlass/util/GPU_Clock.hpp"
#include "cutlass/util/command_line.h"
#include "cutlass/util/helper_cuda.hpp"
#include "cutlass/util/print_error.hpp"

#include "cutlass/detail/layout.hpp"

#include "cuda_launch.hpp"
#include "shared_storage.h"
#include "smem_helper.hpp"


template <typename _TiledCopyS, typename _TiledCopyD, typename _GmemLayout,typename _GmemLayout_load,
          typename _SmemLayout, typename _TileShape>
struct Params {
  using TiledCopyS = _TiledCopyS;
  using TiledCopyD = _TiledCopyD;
  using GmemLayout = _GmemLayout;
  using GmemLayout_load = _GmemLayout_load;
  using SmemLayout = _SmemLayout;
  using TileShape = _TileShape;

  TiledCopyS const tmaLoad;
  TiledCopyD const tmaStore;
  GmemLayout const gmemLayout;
  GmemLayout_load const gmemLayout_load;
  SmemLayout const smemLayout;
  TileShape const tileShape;

  Params(_TiledCopyS const &tmaLoad, _TiledCopyD const &tmaStore,
         _GmemLayout const &gmemLayout,_GmemLayout_load const &gmemLayout_load, _SmemLayout const &smemLayout,
         _TileShape const &tileShape)
      : tmaLoad(tmaLoad), tmaStore(tmaStore), gmemLayout(gmemLayout),gmemLayout_load(gmemLayout_load),
        smemLayout(smemLayout), tileShape(tileShape) {}
};

template <int kNumThreads, class Element, class Params>
__global__ static void __launch_bounds__(kNumThreads, 1)
    copyTMAKernel(CUTE_GRID_CONSTANT Params const params) {
  using namespace cute;
  using X = Underscore; 
  //
  // Get layouts and tiled copies from Params struct
  //
  using GmemLayout = typename Params::GmemLayout;
  using GmemLayout_load = typename Params::GmemLayout_load;
  using SmemLayout = typename Params::SmemLayout;
  using TileShape = typename Params::TileShape;

  auto &tmaLoad = params.tmaLoad;
  auto &tmaStore = params.tmaStore;
  auto &gmemLayout = params.gmemLayout;
  auto &gmemLayout_load = params.gmemLayout_load;
  auto &smemLayout = params.smemLayout;
  auto &tileShape = params.tileShape;

  // if(blockIdx.x==0&&blockIdx.y==0&&threadIdx.x==0&&threadIdx.y==0){
  //   print(params.gmemLayout);
  //   printf("   params.gmemLayout\n");
  // } // 证实了：在外面修改Params能够改变里面的gemmLayout  (16384,128):(128,_1)  (reduce)

  // Use Shared Storage structure to allocate aligned SMEM addresses.
  extern __shared__ char shared_memory[];
  using SharedStorage = SharedStorageTMA<Element, SmemLayout>;
  SharedStorage &shared_storage =
      *reinterpret_cast<SharedStorage *>(shared_memory);





  // // 将 smem_ptr 作为 Element 类型的指针
  // Element* smem_ptr = reinterpret_cast<Element*>(shared_storage.smem.data());

  // if (threadIdx.x == 0 && threadIdx.y == 0) {
  //     for (int i = 0; i < 128 * 128; ++i) {
  //         smem_ptr[i] = static_cast<Element>(i);  // 初始化为从 0 到 128*128 的值
  //     }
  // }
  // // Define smem tensor
  // Tensor sS =
  //     make_tensor(make_smem_ptr(smem_ptr), smemLayout);




  // Define smem tensor
  Tensor sS =
      make_tensor(make_smem_ptr(shared_storage.smem.data()), smemLayout);
  // Get mbarrier object and its value type
  auto &mbarrier = shared_storage.mbarrier;
  using BarrierType = cutlass::arch::ClusterTransactionBarrier::ValueType;
  static_assert(cute::is_same_v<BarrierType, uint64_t>,
                "Value type of mbarrier is uint64_t.");

  // Constants used for TMA
  const int warp_idx = cutlass::canonical_warp_idx_sync();
  const bool lane_predicate = cute::elect_one_sync();
  constexpr int kTmaTransactionBytes =
      sizeof(ArrayEngine<Element, size(SmemLayout{})>);

  // Prefetch TMA descriptors for load and store
  if (warp_idx == 0 && lane_predicate) {
    prefetch_tma_descriptor(tmaLoad.get_tma_descriptor());
    prefetch_tma_descriptor(tmaStore.get_tma_descriptor());
  }

  // Get CTA view of gmem tensor
  Tensor mS = tmaLoad.get_tma_tensor(shape(gmemLayout_load));
  auto blkCoord = make_coord(blockIdx.x, blockIdx.y);
  Tensor gS = local_tile(mS, tileShape, blkCoord);

  auto cta_tmaS = tmaLoad.get_slice(Int<0>{});

  if (warp_idx == 0 and lane_predicate) {
    mbarrier.init(1 /* arrive count */);
    mbarrier.arrive_and_expect_tx(kTmaTransactionBytes);
    copy(tmaLoad.with(reinterpret_cast<BarrierType &>(mbarrier)),
         cta_tmaS.partition_S(gS), cta_tmaS.partition_D(sS));
  }
  __syncthreads();


  // if(blockIdx.x==0&&blockIdx.y==0&&threadIdx.x==0&&threadIdx.y==0){
  //   print_tensor(sS);
  //   printf("    sS\n");
  // }


  mbarrier.wait(0 /* phase */);
  
  cutlass::arch::fence_view_async_shared();

  // Get CTA view of gmem out tensor
  auto mD = tmaStore.get_tma_tensor(shape(gmemLayout));
  auto blkCoord_reduce = make_coord(blockIdx.x, 0);
  auto gD = local_tile(mD, tileShape, blkCoord_reduce);

  auto cta_tmaD = tmaStore.get_slice(Int<0>{});

  if (warp_idx == 0 and lane_predicate) {
    cute::copy(tmaStore, cta_tmaD.partition_S(sS), cta_tmaD.partition_D(gD));
    // cute::tma_store_arrive(); 
  }
  // cute::tma_store_wait<0>();
}

template <int TILE_M = 128, int TILE_N = 128, int THREADS = 32>
int copy_host_tma_load_and_store_kernel(int M, int N, int iterations, int print_out, const std::string& reduce_or_store = "store") {
  using namespace cute;

  printf("Copy with TMA load and store -- no swizzling.\n");

  using Element = cutlass::half_t;

  auto tensor_shape = make_shape(M, N);
  auto tensor_shape_reduce = make_shape(M, 128);

  // Allocate and initialize
  thrust::host_vector<Element> h_S(size(tensor_shape)); // (M, N)
  thrust::host_vector<Element> h_D(size(tensor_shape)); // (M, N)
  thrust::host_vector<Element> h_D_reduce_correct(size(tensor_shape_reduce)); // (M, 128)
  thrust::host_vector<Element> h_D_reduce_copy_back(size(tensor_shape_reduce)); // (M, 128)



  // for (size_t i = 0; i < h_S.size(); ++i)
  //   h_S[i] = static_cast<Element>(float(i));

  for (size_t m = 0; m < M; ++m){
    for (size_t n = 0; n < N; ++n){
      h_S[m*N+n] = static_cast<Element>(float(m*N+n));
      // h_S[m*N+n] = static_cast<Element>(1);
    }
  } // row major  


  for (size_t m = 0; m < M; ++m){
    for (size_t n = 0; n < 128; ++n){
      // h_S[m*N+n] = static_cast<Element>(float(m*N+n)*1e-3);
      h_D_reduce_copy_back[m*128+n] = static_cast<Element>(0);
    }
  } // row major


  // Manually specify values for h_D_reduce_correct
  for (size_t m = 0; m < M; ++m){
    for (size_t n = 0; n < 128; ++n){
      h_D_reduce_correct[m*128+n]=0;
      for (size_t t = 0; t < N/128; ++t){
        h_D_reduce_correct[m*128+n] += h_S[m*N+n+t*128];
      }
    }
  } // row major

  thrust::device_vector<Element> d_S = h_S;
  thrust::device_vector<Element> d_D = h_D;
  thrust::device_vector<Element> d_D_reduce = h_D_reduce_correct;
  thrust::device_vector<Element> d_D_reduce_copy_back = h_D_reduce_copy_back;
  //
  // Make tensors
  //

  auto gmemLayoutS = make_layout(tensor_shape, LayoutRight{});
  auto gmemLayoutD = make_layout(tensor_shape, LayoutRight{});
  auto gmemLayoutD_reduce = make_layout(tensor_shape_reduce, LayoutRight{});
  Tensor tensor_S = make_tensor(
      make_gmem_ptr(thrust::raw_pointer_cast(d_S.data())), gmemLayoutS);
  Tensor tensor_D = make_tensor(
      make_gmem_ptr(thrust::raw_pointer_cast(d_D.data())), gmemLayoutD);
  Tensor tensor_D_reduce = make_tensor(
      make_gmem_ptr(thrust::raw_pointer_cast(d_D_reduce_copy_back.data())), gmemLayoutD_reduce);

  using bM = Int<TILE_M>;
  using bN = Int<TILE_N>;

  auto tileShape = make_shape(bM{}, bN{});
  // NOTE: same smem layout for TMA load and store
  auto smemLayout = make_layout(tileShape, LayoutRight{});
  auto tma_load =
      make_tma_copy(SM90_TMA_LOAD{}, tensor_S, smemLayout);
  // print(tma_load);

  auto tma_store = make_tma_copy(SM90_TMA_STORE{}, tensor_D, smemLayout);
  // print(tma_store);

  auto tma_reduce = make_tma_copy(SM90_TMA_REDUCE_ADD{}, tensor_D_reduce, smemLayout);
  // print(tma_store);


  // if(reduce_or_store=="store"){

  //   Params params(tma_load, tma_store, gmemLayoutS, smemLayout, tileShape);

  //   dim3 gridDim(ceil_div(M, TILE_M), ceil_div(N, TILE_N));
  //   dim3 blockDim(THREADS);

  //   int smem_size = int(sizeof(SharedStorageTMA<Element, decltype(smemLayout)>));
  //   printf("smem size: %d.\n", smem_size);

  //   void const *kernel =
  //       (void const *)copyTMAKernel<THREADS, Element, decltype(params)>;
  //   cfk::utils::set_smem_size(smem_size, kernel);

  //   dim3 cluster_dims(1);

  //   // Define the cluster launch parameter structure.
  //   cutlass::ClusterLaunchParams launch_params{gridDim, blockDim, cluster_dims,
  //                                             smem_size};

  //   for (int i = 0; i < iterations; i++) {
  //     auto t1 = std::chrono::high_resolution_clock::now();    
  //     cutlass::Status status =
  //         cutlass::launch_kernel_on_cluster(launch_params, kernel, params);
  //     cudaError result = cudaDeviceSynchronize();
  //     auto t2 = std::chrono::high_resolution_clock::now();
  //     if (result != cudaSuccess) {
  //       std::cerr << "CUDA Runtime error: " << cudaGetErrorString(result)
  //                 << std::endl;
  //       return -1;
  //     }
  //     std::chrono::duration<double, std::milli> tDiff = t2 - t1;
  //     double time_ms = tDiff.count();
  //     std::cout << "Trial " << i << " Completed in " << time_ms << "ms ("
  //               << 2e-6 * M * N * sizeof(Element) / time_ms << " GB/s)"
  //               << std::endl;
  //   }

  //   //
  //   // Verify
  //   //

  //   h_D = d_D;

  //   int good = 0, bad = 0;

  //   for (size_t i = 0; i < h_D.size(); ++i) {
  //     if (h_D[i] == h_S[i])
  //       good++;
  //     else
  //       bad++;
  //   }

  //   std::cout << "Success " << good << ", Fail " << bad << std::endl;
  // }
  // else if(reduce_or_store=="reduce"){

  //   // 使用和 store 相同的 Params 结构体，只是传入 tma_reduce 代替 tma_store
  //   Params params(tma_load, tma_reduce, gmemLayoutD_reduce, gmemLayoutS, smemLayout, tileShape);

  //   dim3 gridDim(ceil_div(M, TILE_M), ceil_div(N, TILE_N));
  //   dim3 blockDim(THREADS);

  //   int smem_size = int(sizeof(SharedStorageTMA<Element, decltype(smemLayout)>));
  //   printf("smem size: %d.\n", smem_size);

  //   // 定义内核函数指针，使用相同的 copyTMAKernel 逻辑
  //   void const *kernel =
  //       (void const *)copyTMAKernel<THREADS, Element, decltype(params)>;
  //   cfk::utils::set_smem_size(smem_size, kernel); // cfk是本代码库专门定义的一个namespace，里面只包含set_smem_size函数

  //   dim3 cluster_dims(1);

  //   // 定义集群启动参数
  //   cutlass::ClusterLaunchParams launch_params{gridDim, blockDim, cluster_dims, smem_size};

  //   for (int i = 0; i < iterations; i++) {
  //     auto t1 = std::chrono::high_resolution_clock::now();
  //     cutlass::Status status = cutlass::launch_kernel_on_cluster(launch_params, kernel, params);
  //     cudaError result = cudaDeviceSynchronize();
  //     auto t2 = std::chrono::high_resolution_clock::now();
  //     if (result != cudaSuccess) {
  //       std::cerr << "CUDA Runtime error: " << cudaGetErrorString(result) << std::endl;
  //       return -1;
  //     }
  //     std::chrono::duration<double, std::milli> tDiff = t2 - t1;
  //     double time_ms = tDiff.count();
  //     std::cout << "Trial " << i << " Completed in " << time_ms << "ms ("
  //               << 2e-6 * M * N * sizeof(Element) / time_ms << " GB/s)"
  //               << std::endl;
  //   }

  //   //
  //   // Verify
  //   //

  //   h_D_reduce_copy_back = d_D_reduce;

  //   int good = 0, bad = 0;

  //   // 遍历检查结果，确保 reduce 操作正确
  //   for (size_t i = 0; i < h_D_reduce_correct.size(); ++i) {
  //     if (h_D_reduce_correct[i] == h_D_reduce_copy_back[i]) // 比较结果，看是否与原始数据匹配
  //       good++;
  //     else
  //       bad++;
  //   }

  //   std::cout << "Success " << good << ", Fail " << bad << std::endl;
  // }



    // 使用和 store 相同的 Params 结构体，只是传入 tma_reduce 代替 tma_store
    Params params(tma_load, tma_reduce, gmemLayoutD_reduce, gmemLayoutS, smemLayout, tileShape);

    dim3 gridDim(ceil_div(M, TILE_M), ceil_div(N, TILE_N));
    dim3 blockDim(THREADS);

    int smem_size = int(sizeof(SharedStorageTMA<Element, decltype(smemLayout)>));
    printf("smem size: %d.\n", smem_size);

    // 定义内核函数指针，使用相同的 copyTMAKernel 逻辑
    void const *kernel =
        (void const *)copyTMAKernel<THREADS, Element, decltype(params)>;
    cfk::utils::set_smem_size(smem_size, kernel); // cfk是本代码库专门定义的一个namespace，里面只包含set_smem_size函数

    dim3 cluster_dims(1);

    // 定义集群启动参数
    cutlass::ClusterLaunchParams launch_params{gridDim, blockDim, cluster_dims, smem_size};

    for (int i = 0; i < iterations; i++) {
      auto t1 = std::chrono::high_resolution_clock::now();
      cutlass::Status status = cutlass::launch_kernel_on_cluster(launch_params, kernel, params);
      cudaError result = cudaDeviceSynchronize();
      auto t2 = std::chrono::high_resolution_clock::now();
      if (result != cudaSuccess) {
        std::cerr << "CUDA Runtime error: " << cudaGetErrorString(result) << std::endl;
        return -1;
      }
      std::chrono::duration<double, std::milli> tDiff = t2 - t1;
      double time_ms = tDiff.count();
      std::cout << "Trial " << i << " Completed in " << time_ms << "ms ("
                << 2e-6 * M * N * sizeof(Element) / time_ms << " GB/s)"
                << std::endl;
    }

    //
    // Verify
    //

    h_D_reduce_copy_back = d_D_reduce_copy_back;

    int good = 0, bad = 0;

    // 遍历检查结果，确保 reduce 操作正确
    for (size_t i = 0; i < h_D_reduce_correct.size(); ++i) {
      if (h_D_reduce_correct[i] == h_D_reduce_copy_back[i]) // 比较结果，看是否与原始数据匹配
        good++;
      else
        bad++;
    }

    std::cout << "Success " << good << ", Fail " << bad << std::endl;


  if(print_out==1){
      std::cout << "h_S " << std::endl;
      for (size_t i = 0; i < M; ++i) {
          for (size_t j = 0; j < N; ++j) {
              std::cout << h_S[i * N + j] << " ";  // 根据行列索引打印元素
          }
          std::cout << std::endl;  // 每行打印结束后换行
      }

      if(reduce_or_store=="reduce"){
        std::cout << "h_D_reduce_correct " << std::endl;
        for (size_t i = 0; i < M; ++i) {
            for (size_t j = 0; j < 128; ++j) {
                std::cout << h_D_reduce_correct[i * 128 + j] << " ";  // 根据行列索引打印元素
            }
            std::cout << std::endl;  // 每行打印结束后换行
        }

        std::cout << "h_D_reduce_copy_back " << std::endl;
        for (size_t i = 0; i < M; ++i) {
            for (size_t j = 0; j < 128; ++j) {
                std::cout << h_D_reduce_copy_back[i * 128 + j] << " ";  // 根据行列索引打印元素
            }
            std::cout << std::endl;  // 每行打印结束后换行
        }
      }
  }




  return 0;
}
